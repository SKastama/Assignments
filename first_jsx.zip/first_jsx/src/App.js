import React from 'react';
import './App.css';

function App() {
  return (
    <>                
      <h1>Hello Dojo</h1>                
      <h2>Things I need to do:</h2>
      <ul>Learn React</ul>
      <ul>Climb Mt. Everest</ul>
      <ul>Run a marathon</ul>
      <ul>Feed the dogs</ul>
    </> 
  );
}

export default App;



